# import pandas as pd 
# from data_fetch import download_historical_data

# def arbritage_fetcher(symbol , start_date , end_date):
#     df = download_historical_data(symbol = f'{symbol}.NS' , start_date= start_date , end_date= end_date)
#     df2 = download_historical_data(symbol = f'{symbol}.BO' , start_date= start_date , end_date= end_date)

    
#     return df , df2